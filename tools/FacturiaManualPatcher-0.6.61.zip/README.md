# FACTURIA - Outil de patch manuel

Cet outil permet d'appliquer un patch FACTURIA même si l'application ne démarre plus.

## Utilisation

1. Lancez `Lancer-Patcher-Facturia.bat`.
2. Cliquez sur `Télécharger` pour récupérer le dernier patch proposé, ou sélectionnez un ZIP déjà téléchargé.
3. Vérifiez le dossier d'installation de FACTURIA.
4. Gardez la sauvegarde cochée.
5. Cliquez sur `Appliquer le patch`.

Si FACTURIA est installé dans `C:\Program Files\Facturia`, utilisez le bouton `Relancer en administrateur`.

L'outil remplace uniquement les fichiers de l'application. Il ne supprime pas les bases, sociétés, clients, devis ou factures.
